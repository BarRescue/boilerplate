<?php /* Template Name: Home Template */ ?>
<?php get_header(); ?>

<?php get_footer(); ?>