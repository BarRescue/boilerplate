Default components to pass in:

```
<?php /* Template Name: Template */ ?>
<?php get_header(); ?>

<?php get_footer(); ?>
```
