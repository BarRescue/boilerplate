Try to use class-ed as prefix for every new class that's being created. This will prevent spaghettification of the code.
