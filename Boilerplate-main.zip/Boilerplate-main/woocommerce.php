<?php get_header(); ?>
<section class="wrapper">
	<div class="wrapper__inner">
		<?php woocommerce_content(); ?>
	</div>
</section>
<?php get_footer(); ?>	