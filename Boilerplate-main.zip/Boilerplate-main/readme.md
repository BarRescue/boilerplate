This theme is a boilerplate to start a fresh custom theme.
